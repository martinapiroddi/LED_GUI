/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef __ISR_TIMER_H
    
    #define __ISR_TIMER_H
    
    #include "cytypes.h"
    #include "stdio.h"
    
    CY_ISR_PROTO(Custom_ISR_TIMER);
#endif
    




/* [] END OF FILE */
